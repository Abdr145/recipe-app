from flask import Blueprint, render_template, request, jsonify
import openai
import os
from app.models import Recipe

chatbot_bp = Blueprint('chatbot', __name__)

# Настройка OpenAI
openai.api_key = os.environ.get('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')


@chatbot_bp.route('/chatbot')
def chatbot_page():
    return render_template('chatbot/chat.html')


@chatbot_bp.route('/chatbot/ask', methods=['POST'])
def ask_chatbot():
    user_question = request.json.get('question')

    try:
        # Получаем контекст рецептов из базы данных
        recent_recipes = Recipe.query.limit(10).all()
        recipes_context = "\n".join([f"- {r.title}: {r.description[:100]}..." for r in recent_recipes])

        # Системный промпт для кулинарного помощника
        system_prompt = f"""
        Ты опытный повар и кулинарный консультант. Отвечай на русском языке.

        Ты помогаешь с:
        - Рецептами и способами приготовления
        - Заменой ингредиентов  
        - Кулинарными советами и техниками
        - Планированием меню
        - Хранением продуктов

        Доступные рецепты в нашей базе:
        {recipes_context}

        Отвечай дружелюбно, с энтузиазмом и давай практические советы.
        """

        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_question}
            ],
            max_tokens=500,
            temperature=0.7
        )

        bot_response = response.choices[0].message.content
        return jsonify({'response': bot_response})

    except Exception as e:
        return jsonify({'error': 'Извините, произошла ошибка. Попробуйте еще раз.'}), 500

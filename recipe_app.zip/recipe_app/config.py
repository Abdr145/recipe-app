import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your_secret_key'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'app', 'static', 'uploads')
    OPENAI_API_KEY = os.environ.get('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')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
